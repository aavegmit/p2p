#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<signal.h>

extern void my_handler(int nSig);
